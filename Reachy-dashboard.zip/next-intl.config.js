// next-intl.config.js
module.exports = {
    locales: ['ar', 'en'],
    defaultLocale: 'ar',
    localeDetection: false
  };